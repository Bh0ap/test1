import React, { memo } from 'react';

function AdminPage() {
  return (
    <>
      <div
        style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100vh',
        }}
      >
        Deprecated
      </div>
    </>
  );
}

export default memo(AdminPage);
